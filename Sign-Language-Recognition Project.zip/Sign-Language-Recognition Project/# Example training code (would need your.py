# Example training code (would need your dataset)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

def build_model(input_shape, num_classes):
    model = Sequential([
        LSTM(64, return_sequences=True, input_shape=input_shape),
        LSTM(64),
        Dense(64, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

# Assuming you have X_train (sequences) and y_train (labels)
model = build_model((30, 64), len(gestures))
model.fit(X_train, y_train, epochs=50, batch_size=32)
model.save('sign_language_model.h5')